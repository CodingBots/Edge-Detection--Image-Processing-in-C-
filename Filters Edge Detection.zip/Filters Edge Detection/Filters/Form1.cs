﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Filters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private double[,] GetFilter()
        {
            try
            {
                return new double[,] 
                { { double.Parse(textBox00.Text), double.Parse(textBox01.Text), double.Parse(textBox02.Text) },
                  { double.Parse(textBox10.Text), double.Parse(textBox11.Text), double.Parse(textBox12.Text) },
                  { double.Parse(textBox20.Text), double.Parse(textBox21.Text), double.Parse(textBox22.Text) },
                };
            }
            catch
            {
                return null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[ , ] filter = GetFilter();
            if (filter != null)
                ApplyFilter(filter);
        }

        private void ApplyFilter(double[,] filter)
        {
            try
            {
                Bitmap Original = new Bitmap(pictureBoxOriginal.Image);
                Bitmap outImage = new Bitmap(Original.Width, Original.Height);
                Color[,] FilterColors = new Color[Original.Width, Original.Height];

                // Iterating Image
                for (int y = 1; y < Original.Height-1 ; y++)
                {
                    for (int x = 1; x < (Original.Width-1) ; x++)
                    {
                        double[,] neighboursRed = GetNeighboursRed(y, x, Original);
                        double[,] neighboursGreen = GetNeighboursGreen(y, x, Original);
                        double[,] neighboursBlue = GetNeighboursBlue(y, x, Original);

                        double newPixelValueRed = 0;
                        double newPixelValueGreen = 0;
                        double newPixelValueBlue = 0;

                        for (int i = 0; i < 3; i++)
                        {
                            for (int j = 0; j < 3; j++)
                            {
                                newPixelValueRed += neighboursRed[i, j] * filter[i, j];
                                newPixelValueGreen += neighboursGreen[i, j] * filter[i, j];
                                newPixelValueBlue += neighboursBlue[i, j] * filter[i, j];
                            }
                        }

                        newPixelValueRed = Math.Min(Math.Max(newPixelValueRed, 0), 255);
                        newPixelValueGreen = Math.Min(Math.Max(newPixelValueGreen, 0), 255);
                        newPixelValueBlue = Math.Min(Math.Max(newPixelValueBlue, 0), 255);

                        FilterColors[x, y] = Color.FromArgb((int)newPixelValueRed, (int)newPixelValueGreen, (int)newPixelValueBlue);
                    }
                }

                // Making new Image
                for (int i = 0; i < Original.Height; i++)
                    for (int j = 0; j < Original.Width; j++)
                        outImage.SetPixel(j, i, FilterColors[j, i]);

                pictureBoxFiltered.Image = outImage;
            }
            catch
            {
                MessageBox.Show("Please select the image");
            }
        }

        private double[,] GetNeighboursRed(int x, int y, Bitmap img)
        {
            return new double[ , ] 
            {
                {img.GetPixel(y - 1, x - 1).R, img.GetPixel(y - 1, x).R, img.GetPixel(y - 1, x + 1).R},
                {img.GetPixel(y, x - 1).R, img.GetPixel(y, x).R, img.GetPixel(y, x + 1).R},
                {img.GetPixel(y + 1, x - 1).R, img.GetPixel(y + 1, x).R, img.GetPixel(y + 1, x + 1).R}
            };
        }

        private double[,] GetNeighboursBlue(int x, int y, Bitmap img)
        {
            return new double[,] 
            {
                {img.GetPixel(y - 1, x - 1).B, img.GetPixel(y - 1, x).B, img.GetPixel(y - 1, x + 1).B},
                {img.GetPixel(y, x - 1).B, img.GetPixel(y, x).B, img.GetPixel(y, x + 1).B},
                {img.GetPixel(y + 1, x - 1).B, img.GetPixel(y + 1, x).B, img.GetPixel(y + 1, x + 1).B}
            };
        }

        private double[,] GetNeighboursGreen(int x, int y, Bitmap img)
        {
            return new double[,] 
            {
                {img.GetPixel(y - 1, x - 1).G, img.GetPixel(y - 1, x).G, img.GetPixel(y - 1, x + 1).G},
                {img.GetPixel(y, x - 1).G, img.GetPixel(y, x).G, img.GetPixel(y, x + 1).G},
                {img.GetPixel(y + 1, x - 1).G, img.GetPixel(y + 1, x).G, img.GetPixel(y + 1, x + 1).G}
            };
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxOriginal.ImageLocation = ofd.FileName;
            }
        }

        private void buttonSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "(JPG)|*.jpg|(Bitmap)|*.bmp";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxFiltered.Image.Save(sfd.FileName);
            }
        }
    }
}
